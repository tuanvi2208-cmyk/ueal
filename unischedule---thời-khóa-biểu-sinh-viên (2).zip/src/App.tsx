/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, type ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Calendar, 
  Clock, 
  BookOpen, 
  Coffee, 
  Moon, 
  Sun, 
  GraduationCap,
  ChevronRight,
  Info
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

// --- Types ---
type Subject = {
  name: string;
  difficulty: "hard" | "medium" | "easy";
  color: string;
  icon: ReactNode;
};

type ScheduleItem = {
  time: string;
  subject: string;
  type: "class" | "break" | "study";
};

type DaySchedule = {
  day: string;
  items: ScheduleItem[];
};

// --- Constants ---
const SUBJECTS: Record<string, Subject> = {
  "Toán cao cấp": { 
    name: "Toán cao cấp", 
    difficulty: "hard", 
    color: "bg-orange-100 text-orange-700 border-orange-200",
    icon: <span className="text-xs font-bold">∑</span>
  },
  "Tin học": { 
    name: "Tin học", 
    difficulty: "medium", 
    color: "bg-blue-100 text-blue-700 border-blue-200",
    icon: <span className="text-xs font-bold">01</span>
  },
  "Kinh tế": { 
    name: "Kinh tế", 
    difficulty: "medium", 
    color: "bg-emerald-100 text-emerald-700 border-emerald-200",
    icon: <span className="text-xs font-bold">$</span>
  },
  "Tiếng Anh": { 
    name: "Tiếng Anh", 
    difficulty: "medium", 
    color: "bg-purple-100 text-purple-700 border-purple-200",
    icon: <span className="text-xs font-bold">EN</span>
  },
  "Pháp luật": { 
    name: "Pháp luật", 
    difficulty: "easy", 
    color: "bg-slate-100 text-slate-700 border-slate-200",
    icon: <span className="text-xs font-bold">§</span>
  },
  "Nghỉ giải lao": { 
    name: "Nghỉ giải lao", 
    difficulty: "easy", 
    color: "bg-amber-50 text-amber-600 border-amber-100 italic",
    icon: <Coffee className="w-3 h-3" />
  },
  "Tự học": { 
    name: "Tự học", 
    difficulty: "medium", 
    color: "bg-indigo-50 text-indigo-700 border-indigo-100",
    icon: <Moon className="w-3 h-3" />
  }
};

const SCHEDULE: DaySchedule[] = [
  {
    day: "Thứ 2",
    items: [
      { time: "07:30 - 09:00", subject: "Toán cao cấp", type: "class" },
      { time: "09:00 - 09:15", subject: "Nghỉ giải lao", type: "break" },
      { time: "09:15 - 10:45", subject: "Tiếng Anh", type: "class" },
      { time: "10:45 - 11:00", subject: "Nghỉ giải lao", type: "break" },
      { time: "11:00 - 12:30", subject: "Pháp luật", type: "class" },
      { time: "19:00 - 21:00", subject: "Tự học", type: "study" },
    ]
  },
  {
    day: "Thứ 3",
    items: [
      { time: "07:30 - 09:00", subject: "Kinh tế", type: "class" },
      { time: "09:00 - 09:15", subject: "Nghỉ giải lao", type: "break" },
      { time: "09:15 - 10:45", subject: "Tin học", type: "class" },
      { time: "10:45 - 11:00", subject: "Nghỉ giải lao", type: "break" },
      { time: "11:00 - 12:30", subject: "Toán cao cấp", type: "class" },
      { time: "19:00 - 21:00", subject: "Tự học", type: "study" },
    ]
  },
  {
    day: "Thứ 4",
    items: [
      { time: "07:30 - 09:00", subject: "Tin học", type: "class" },
      { time: "09:00 - 09:15", subject: "Nghỉ giải lao", type: "break" },
      { time: "09:15 - 10:45", subject: "Tiếng Anh", type: "class" },
      { time: "10:45 - 11:00", subject: "Nghỉ giải lao", type: "break" },
      { time: "11:00 - 12:30", subject: "Kinh tế", type: "class" },
      { time: "19:00 - 21:00", subject: "Tự học", type: "study" },
    ]
  },
  {
    day: "Thứ 5",
    items: [
      { time: "07:30 - 09:00", subject: "Pháp luật", type: "class" },
      { time: "09:00 - 09:15", subject: "Nghỉ giải lao", type: "break" },
      { time: "09:15 - 10:45", subject: "Toán cao cấp", type: "class" },
      { time: "10:45 - 11:00", subject: "Nghỉ giải lao", type: "break" },
      { time: "11:00 - 12:30", subject: "Tin học", type: "class" },
      { time: "19:00 - 21:00", subject: "Tự học", type: "study" },
    ]
  },
  {
    day: "Thứ 6",
    items: [
      { time: "07:30 - 09:00", subject: "Tiếng Anh", type: "class" },
      { time: "09:00 - 09:15", subject: "Nghỉ giải lao", type: "break" },
      { time: "09:15 - 10:45", subject: "Kinh tế", type: "class" },
      { time: "10:45 - 11:00", subject: "Nghỉ giải lao", type: "break" },
      { time: "11:00 - 12:30", subject: "Pháp luật", type: "class" },
      { time: "19:00 - 21:00", subject: "Tự học", type: "study" },
    ]
  },
  {
    day: "Thứ 7",
    items: [
      { time: "07:30 - 09:00", subject: "Toán cao cấp", type: "class" },
      { time: "09:00 - 09:15", subject: "Nghỉ giải lao", type: "break" },
      { time: "09:15 - 10:45", subject: "Tin học", type: "class" },
      { time: "10:45 - 11:00", subject: "Nghỉ giải lao", type: "break" },
      { time: "11:00 - 12:30", subject: "Tiếng Anh", type: "class" },
      { time: "14:00 - 16:00", subject: "Tự học", type: "study" },
    ]
  }
];

export default function App() {
  const [activeDay, setActiveDay] = useState("Thứ 2");

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Header Section */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900 leading-none">UniSchedule</h1>
              <p className="text-xs font-medium text-slate-500 mt-1">Kế hoạch học tập tối ưu</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-4">
            <Badge variant="outline" className="bg-slate-50 text-slate-600 border-slate-200 font-medium px-3 py-1">
              Học kỳ 1 • 2024
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Summary & Info */}
          <div className="lg:col-span-4 space-y-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-none shadow-sm overflow-hidden bg-white">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Info className="w-5 h-5 text-indigo-500" />
                    Tổng quan môn học
                  </CardTitle>
                  <CardDescription>Danh sách các môn học trong học kỳ này</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {Object.entries(SUBJECTS).filter(([name]) => !["Nghỉ giải lao", "Tự học"].includes(name)).map(([name, sub]) => (
                    <div key={name} className="flex items-center justify-between p-3 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:shadow-md hover:border-indigo-100 transition-all duration-200 group">
                      <div className="flex items-center gap-3">
                        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center border", sub.color)}>
                          {sub.icon}
                        </div>
                        <span className="font-semibold text-sm text-slate-700">{name}</span>
                      </div>
                      <Badge variant="secondary" className={cn("text-[10px] uppercase tracking-wider font-bold px-2 py-0.5", 
                        sub.difficulty === "hard" ? "bg-orange-100 text-orange-700" : 
                        sub.difficulty === "medium" ? "bg-blue-100 text-blue-700" : "bg-slate-100 text-slate-600"
                      )}>
                        {sub.difficulty === "hard" ? "Khó" : sub.difficulty === "medium" ? "TB" : "Dễ"}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="bg-indigo-600 border-none text-white overflow-hidden relative">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <BookOpen className="w-24 h-24 rotate-12" />
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">Lời khuyên học tập</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 relative z-10">
                  <p className="text-indigo-100 text-sm leading-relaxed">
                    "Hãy tập trung vào các môn khó như <span className="font-bold text-white">Toán cao cấp</span> vào buổi sáng khi trí não minh mẫn nhất."
                  </p>
                  <div className="flex items-center gap-2 text-xs font-medium bg-white/10 p-2 rounded-lg border border-white/10">
                    <Sun className="w-4 h-4" />
                    <span>Nghỉ ngơi 15p sau mỗi 90p học tập</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Right Column: Timetable */}
          <div className="lg:col-span-8 space-y-6">
            <Card className="border-none shadow-sm bg-white">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-6">
                <div className="space-y-1">
                  <CardTitle className="text-2xl font-bold tracking-tight">Thời Khóa Biểu</CardTitle>
                  <CardDescription>Lịch trình chi tiết từ thứ 2 đến thứ 7</CardDescription>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <Calendar className="w-5 h-5" />
                  <span className="text-sm font-medium">Tuần 12</span>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs value={activeDay} onValueChange={setActiveDay} className="w-full">
                  <TabsList className="grid grid-cols-3 sm:grid-cols-6 h-auto p-1 bg-slate-100 rounded-xl mb-8">
                    {SCHEDULE.map((day) => (
                      <TabsTrigger 
                        key={day.day} 
                        value={day.day}
                        className="rounded-lg py-2.5 text-sm font-semibold data-[state=active]:bg-white data-[state=active]:text-indigo-600 data-[state=active]:shadow-sm transition-all"
                      >
                        {day.day}
                      </TabsTrigger>
                    ))}
                  </TabsList>

                  <AnimatePresence mode="wait">
                    {SCHEDULE.map((day) => (
                      <TabsContent key={day.day} value={day.day} className="mt-0 outline-none">
                        <motion.div
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          transition={{ duration: 0.3 }}
                          className="space-y-4"
                        >
                          <div className="rounded-2xl border border-slate-100 overflow-hidden">
                            <Table>
                              <TableHeader className="bg-slate-50/50">
                                <TableRow className="hover:bg-transparent border-slate-100">
                                  <TableHead className="w-[180px] font-bold text-slate-500 uppercase tracking-wider text-[10px]">Thời gian</TableHead>
                                  <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">Hoạt động / Môn học</TableHead>
                                  <TableHead className="text-right font-bold text-slate-500 uppercase tracking-wider text-[10px]">Trạng thái</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {day.items.map((item, idx) => {
                                  const sub = SUBJECTS[item.subject];
                                  return (
                                    <TableRow key={idx} className="group hover:bg-slate-50/50 border-slate-100 transition-colors">
                                      <TableCell className="py-5">
                                        <div className="flex items-center gap-2 text-slate-600 font-medium">
                                          <Clock className="w-4 h-4 text-slate-400" />
                                          <span className="text-sm tabular-nums">{item.time}</span>
                                        </div>
                                      </TableCell>
                                      <TableCell className="py-5">
                                        <div className="flex items-center gap-3">
                                          <div className={cn(
                                            "w-10 h-10 rounded-xl flex items-center justify-center border shadow-sm transition-transform group-hover:scale-110 duration-200",
                                            sub.color
                                          )}>
                                            {sub.icon}
                                          </div>
                                          <div>
                                            <p className="font-bold text-slate-800 text-sm leading-none">{item.subject}</p>
                                            <p className="text-[11px] text-slate-500 mt-1.5 font-medium flex items-center gap-1">
                                              {item.type === "class" ? "Giảng đường A1" : item.type === "break" ? "Canteen" : "Thư viện / Tại nhà"}
                                            </p>
                                          </div>
                                        </div>
                                      </TableCell>
                                      <TableCell className="text-right py-5">
                                        <Badge 
                                          variant="outline" 
                                          className={cn(
                                            "font-bold text-[10px] uppercase tracking-tighter px-2 py-0.5 border-none",
                                            item.type === "class" ? "bg-indigo-50 text-indigo-600" : 
                                            item.type === "break" ? "bg-amber-50 text-amber-600" : "bg-emerald-50 text-emerald-600"
                                          )}
                                        >
                                          {item.type === "class" ? "Học chính" : item.type === "break" ? "Nghỉ ngơi" : "Tự học"}
                                        </Badge>
                                      </TableCell>
                                    </TableRow>
                                  );
                                })}
                              </TableBody>
                            </Table>
                          </div>

                          {/* Evening Highlight */}
                          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center text-indigo-600">
                                <Moon className="w-4 h-4" />
                              </div>
                              <div>
                                <p className="text-xs font-bold text-slate-800">Tự học buổi tối</p>
                                <p className="text-[10px] text-slate-500 font-medium">Ôn tập lại kiến thức đã học trong ngày</p>
                              </div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-slate-300" />
                          </div>
                        </motion.div>
                      </TabsContent>
                    ))}
                  </AnimatePresence>
                </Tabs>
              </CardContent>
            </Card>

            {/* Bottom Grid: Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {[
                { label: "Tổng số tiết", value: "24", icon: <BookOpen className="w-4 h-4" />, color: "text-blue-600 bg-blue-50" },
                { label: "Giờ tự học", value: "12h", icon: <Moon className="w-4 h-4" />, color: "text-indigo-600 bg-indigo-50" },
                { label: "Độ khó TB", value: "Vừa", icon: <GraduationCap className="w-4 h-4" />, color: "text-emerald-600 bg-emerald-50" },
              ].map((stat, i) => (
                <Card key={i} className="border-none shadow-sm bg-white">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", stat.color)}>
                      {stat.icon}
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{stat.label}</p>
                      <p className="text-xl font-black text-slate-800 leading-tight">{stat.value}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-t border-slate-200 mt-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 opacity-50 grayscale">
            <GraduationCap className="w-5 h-5" />
            <span className="text-sm font-bold tracking-tight">UniSchedule</span>
          </div>
          <p className="text-xs text-slate-400 font-medium">
            Thiết kế bởi AI Studio • Dành cho sinh viên năm nhất
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-xs font-bold text-slate-400 hover:text-indigo-600 transition-colors">Trợ giúp</a>
            <a href="#" className="text-xs font-bold text-slate-400 hover:text-indigo-600 transition-colors">Cài đặt</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
